# UberLikeApplicationService
Node JS Restful APIs for Uber like application services <br>
##Dependencies
###Express
 npm install --save express <br>
###Cross origin resource sharing
 npm install --save cors <br>
###Jada
 npm install --save jada <br>
###MongoDB
 npm install --save mongodb <br>
 npm install --save mongoose <br>
 npm install --save kerberos <br>
